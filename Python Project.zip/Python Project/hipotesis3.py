import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Extraer día de la semana
data['Día de la semana'] = data['Fecha del evento'].dt.day_name()

#Definir el orden correcto de los días
dias_ordenados = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
data['Día de la semana'] = pd.Categorical(data['Día de la semana'], categories=dias_ordenados, ordered=True)

#Agrupar por día de la semana y tipo de evento
conteo = data.groupby(['Día de la semana', 'Tipo de evento']).size().reset_index(name='Cantidad')

#Gráfico
plt.figure(figsize=(10, 6))
sns.barplot(data=conteo, x='Día de la semana', y='Cantidad', hue='Tipo de evento', palette='Set2')
plt.title('Cantidad de eventos por tipo y día de la semana')
plt.xlabel('Día de la semana')
plt.ylabel('Cantidad de eventos')
plt.legend(title='Tipo de evento', loc='upper left')
plt.tight_layout()
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.show()

#Crear tabla resumen ordenada, reemplazar NaN con 0
resumen = conteo.pivot(index='Día de la semana', columns='Tipo de evento', values='Cantidad').fillna(0).astype(int)
print(resumen)
