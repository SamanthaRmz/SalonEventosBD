import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt

#Cargar datos
data = pd.read_csv('eventos_limpios.csv')

#Contar cuántos eventos por temporada favorita
eventos_por_temporada = data['Temporada favorita para realizar eventos'].value_counts()

#Imprimir los resultados
print("Cantidad de eventos por temporada favorita:")
print(eventos_por_temporada)

#Gráfica
plt.figure(figsize=(8, 6))
eventos_por_temporada.plot(kind='bar', color='lightgreen')
plt.title('Eventos por temporada favorita')
plt.xlabel('Temporada')
plt.ylabel('Cantidad de eventos')
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()


######################## PARTE 2 EVENTOS EN DIAS FESTIVOS ########################
#Lista de fechas festivas que consideraré (solo mes y día)
festivos = [
    (1, 1),    # Año Nuevo
    (2, 14),   # Día del Amor y la Amistad
    (5, 10),   # Día de las Madres
    (9, 15),   # Grito de Independencia
    (10, 31),  # Halloween
    (11, 2),   # Día de Muertos
    (12, 12),  # Día de la Virgen
    (12, 24),  # Nochebuena
    (12, 25),  # Navidad
    (12, 31),  # Año Nuevo (noche)
]

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Extraer mes y día de cada fecha
data['Mes'] = data['Fecha del evento'].dt.month
data['Dia'] = data['Fecha del evento'].dt.day

#Lista de festivos como set para búsqueda rápida
festivos_set = set(festivos)

#Marcar si la fecha es festiva
data['¿Es festivo?'] = data.apply(lambda row: (row['Mes'], row['Dia']) in festivos_set, axis=1)

#Contar cuántos eventos hubo en días festivos vs no festivos
conteo_festivos = data['¿Es festivo?'].value_counts()

#Mostrar resultados
print("\nCantidad de eventos en días festivos vs no festivos:")
print(conteo_festivos)

#Reetiquetar los índices para el gráfico
conteo_festivos.index = conteo_festivos.index.map({True: "Festivos", False: "No festivos"})

#Gráfica
plt.figure(figsize=(6, 4))
conteo_festivos.plot(kind='bar', color=['salmon', 'skyblue'])
plt.title("Eventos en días festivos vs no festivos")
plt.ylabel("Cantidad de eventos")
plt.xticks(rotation=0)
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
