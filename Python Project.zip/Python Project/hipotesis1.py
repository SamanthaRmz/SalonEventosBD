import pandas as pd
import matplotlib.pyplot as plt

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Extraer el número de mes
data['Mes'] = data['Fecha del evento'].dt.month

#Contar eventos por mes y asegurar que estén todos los meses
eventos_por_mes = data['Mes'].value_counts().sort_index()
eventos_por_mes = eventos_por_mes.reindex(range(1, 13), fill_value=0)

#Crear etiquetas de los meses
meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
         'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

#Imprimir la tabla en consola
print("\nCantidad de eventos por mes:")
for i in range(12):
    print(f"{meses[i]}: {eventos_por_mes[i+1]} eventos")

#Graficar
plt.figure(figsize=(10, 6))
plt.bar(meses, eventos_por_mes, color='skyblue')
plt.title('Cantidad total de eventos por mes (sin importar el año)')
plt.xlabel('Mes')
plt.ylabel('Cantidad de eventos')
plt.xticks(rotation=45)
plt.tight_layout()
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()
