import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

#Carga de datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Extraeción de mes y dia
data['Mes'] = data['Fecha del evento'].dt.month
data['DiaSemana'] = data['Fecha del evento'].dt.dayofweek  # 0 = Lunes, 6 = Domingo

#Contar los eventos por mes y día
heatmap_data = data.pivot_table(index='Mes', columns='DiaSemana', aggfunc='size', fill_value=0)

#Crear el mapa de calor
plt.figure(figsize=(10, 6))
sns.heatmap(heatmap_data, cmap='coolwarm', annot=True, fmt='d', linewidths=0.5) # Annot para quitar los datos
plt.title('Demanda de Eventos por Mes y Día de la Semana')
plt.xlabel('Día de la Semana (0=Lunes, 6=Domingo)')
plt.ylabel('Mes del Año')
plt.show()

#Muestra los meses seccionados por dias de la semana y la distribución de la demanda del salon de eventos