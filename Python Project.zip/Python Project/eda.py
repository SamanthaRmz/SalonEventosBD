import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Cargar datos
data = pd.read_csv("eventos_limpios.csv", parse_dates=["Fecha del evento"])

#Ver las primeras filas
print("Primeras filas del dataset:")
print(data.head())

#Información general del dataset
print("\nInformación del dataset:")
print(data.info())

#Estadísticas básicas
print("\nEstadísticas descriptivas:")
print(data.describe(include='all'))

#Revisar valores nulos
print("\nValores nulos por columna:")
print(data.isnull().sum())


################### Gráficas básicas ###################

# 1. Distribución de personas que asistieron
plt.figure(figsize=(8, 5))
sns.histplot(data["Personas que asistieron"], bins=10, kde=True)
plt.title("Distribución de personas que asistieron")
plt.xlabel("Personas que asistieron")
plt.ylabel("Frecuencia")
plt.grid(True)
plt.tight_layout()
plt.show()

# 2. Tipos de evento
plt.figure(figsize=(8, 5))
sns.countplot(data=data, x="Tipo de evento", order=data["Tipo de evento"].value_counts().index)
plt.title("Cantidad de eventos por tipo")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 3. Relación entre personas consideradas vs. asistentes
plt.figure(figsize=(7, 5))
sns.scatterplot(data=data, x="Personas consideradas", y="Personas que asistieron")
plt.title("Personas consideradas vs. asistentes")
plt.tight_layout()
plt.show()
