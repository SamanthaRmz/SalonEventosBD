import pandas as pd
import unicodedata
import re

#Cargar los datos desde un archivo CSV con la codificación adecuada
df = pd.read_csv("Cuestionario bigdata.csv", encoding="utf-8-sig")

#Convertir fechas a formato adecuado
df["Fecha del evento"] = pd.to_datetime(df["Fecha del evento"], format="%d/%m/%y", errors='coerce')

#Función para limpiar texto eliminando caracteres especiales y normalizando
def limpiar_texto(texto):
    if isinstance(texto, str):
        #Normaliza eliminando caracteres especiales y no ASCII
        texto = unicodedata.normalize("NFKD", texto)  #Elimina tildes y caracteres especiales
        texto = re.sub(r'[^\x00-\x7F]+', '', texto)  #Elimina caracteres no ASCII
        texto = re.sub(r'[^a-zA-Z0-9\s,]', '', texto)  #Elimina caracteres especiales que no sean alfanuméricos o espacios
        return texto.strip()  #Quita espacios extra
    return texto

#Aplicar limpieza a cada columna de texto
for col in df.select_dtypes(include=["object"]).columns:
    df[col] = df[col].map(limpiar_texto)

#Revisar y corregir datos mal formateados en 'Hora termino'
if "Hora termino" in df.columns:
    df["Hora termino"] = df["Hora termino"].str.replace(r"^0:00$", "00:00", regex=True)

#Guardar datos limpios en un nuevo archivo CSV
df.to_csv("eventos_limpios.csv", index=False, encoding="utf-8")

#Mostrar los primeros datos limpiados
print(df.head())
