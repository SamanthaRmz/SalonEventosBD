import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

#Cargar datos
data = pd.read_csv("eventos_limpios.csv")

#Seleccionar variables relevantes
features = [
    "Tiempo de anticipacion para renta del salon", "Tipo de evento", "Hora inicio", "Hora termino", 
    "Personas consideradas", "Precio de la renta del salon", "Servicio Extra", "Cual fue el servicio extra"
]

target = "Personas que asistieron"

X = data[features]
y = data[target]

#Codificar variables categóricas
categorical_features = ["Tiempo de anticipacion para renta del salon", "Tipo de evento", "Servicio Extra", "Cual fue el servicio extra"]
numerical_features = ["Hora inicio", "Hora termino", "Personas consideradas", "Precio de la renta del salon"]

encoder = OneHotEncoder(drop="first", handle_unknown="ignore")
scaler = StandardScaler()

X_categorical = encoder.fit_transform(X[categorical_features])
X_numerical = scaler.fit_transform(X[numerical_features])

#Convertir a dataFrame
X_categorical = pd.DataFrame(X_categorical.toarray(), columns=encoder.get_feature_names_out())
X_numerical = pd.DataFrame(X_numerical, columns=numerical_features)

#Concatenar ambas partes
X_processed = pd.concat([X_numerical, X_categorical], axis=1)

#Separar datos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)

#Modelo Random Forest
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

#Predicciones
y_pred = model.predict(X_test)

#Evaluación
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)

print(f"Raíz del Error Cuadrático Medio (RMSE): {round(rmse, 3)}") #Error promedio (en promedio cuántas personas se desvió el modelo de la realidad)
print(f"Coeficiente de determinación (R²): {round(r2, 3)}") #Confiabilidad (del 0 al 1)

#Predice el num de personas que asistirán a un evento, basándose en diferentes factores