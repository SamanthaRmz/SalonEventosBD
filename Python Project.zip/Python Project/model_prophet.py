import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from prophet import Prophet
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Asegurar formato datetime
data['Fecha del evento'] = pd.to_datetime(data['Fecha del evento'])

#Contar eventos por mes
events_per_month = data.resample('ME', on='Fecha del evento').size().reset_index()
events_per_month.columns = ['ds', 'y']  #Prophet requiere estas columnas

#Crear y entrenar el modelo
model = Prophet()
model.fit(events_per_month)

#Generar predicciones para los próximos 12 meses
future = model.make_future_dataframe(periods=12, freq='ME')
forecast = model.predict(future)

#Evaluar la confiabilidad del modelo
actual = events_per_month['y']
predicted = forecast['yhat'][:len(actual)]  #Asegurar que las longitudes coincidan

mae = mean_absolute_error(actual, predicted)
rmse = np.sqrt(mean_squared_error(actual, predicted))
r2 = r2_score(actual, predicted)

#Imprimir en consola las métricas
eval_metrics = f"""
Evaluación del Modelo:
- Error Absoluto Medio (MAE): {mae:.2f}
- Raíz del Error Cuadrático Medio (RMSE): {rmse:.2f}
- Coeficiente de Determinación (R²): {r2:.4f}
"""
print(eval_metrics)

#Graficar resultados
plt.figure(figsize=(12, 6))
plt.plot(events_per_month['ds'], events_per_month['y'], label='Histórico')
plt.plot(forecast['ds'], forecast['yhat'], label='Predicción', linestyle='dashed', color='red')
plt.fill_between(forecast['ds'], forecast['yhat_lower'], forecast['yhat_upper'], color='red', alpha=0.2, label='Intervalo de confianza')
plt.xlabel('Fecha')
plt.ylabel('Número de eventos')
plt.title('Predicción de demanda de eventos (Prophet)')
plt.legend()
plt.show()

#Predice la demanda del salón de eventos en función de la fecha