import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from prophet import Prophet

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Formatear fechas
data['Fecha del evento'] = pd.to_datetime(data['Fecha del evento'])

#Agrupar por mes
events_per_month = data.resample('ME', on='Fecha del evento').size().reset_index()
events_per_month.columns = ['ds', 'y']  # Prophet requiere estos nombres

#Entrenar el modelo
model = Prophet()
model.fit(events_per_month)

#Generar predicción para 12 meses futuros
future = model.make_future_dataframe(periods=12, freq='ME')
forecast = model.predict(future)

#Mostrar predicciones en consola (últimos 12 meses)
predicted_future = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail(12)
print("\nPredicción para los próximos 12 meses:")
print(predicted_future)

#Graficar
plt.figure(figsize=(12, 6))
plt.plot(events_per_month['ds'], events_per_month['y'], label='Histórico')
plt.plot(forecast['ds'], forecast['yhat'], label='Predicción', linestyle='dashed', color='red')
plt.fill_between(forecast['ds'], forecast['yhat_lower'], forecast['yhat_upper'], color='red', alpha=0.2, label='Intervalo de confianza')
plt.xlabel('Fecha')
plt.ylabel('Número de eventos')
plt.title('Predicción mensual de eventos (12 meses)')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
