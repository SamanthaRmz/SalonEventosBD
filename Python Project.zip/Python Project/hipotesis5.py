import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Cargar datos
data = pd.read_csv('eventos_limpios.csv')

#Limpiar datos: quitar filas donde falte anticipación o servicio extra
data = data.dropna(subset=['Tiempo de anticipacion para renta del salon', 'Servicio Extra'])

#Convertir "Tiempo de anticipacion" a categorías numéricas para filtrar
categorias_anticipacion = {
    'Menos de 1 mes antes': 0,
    'Entre 2 y 3 meses antes': 1,
    'Entre 4 y 5 meses antes': 2,
    'Mas de 5 meses antes': 3
}
data['Tiempo de anticipacion para renta del salon'] = data['Tiempo de anticipacion para renta del salon'].map(categorias_anticipacion)

#Filtrar los eventos con menos de 3 meses de anticipación
menos_3_meses = data[data['Tiempo de anticipacion para renta del salon'] <= 1]  # 0 y 1 son menos de 3 meses
mas_3_meses = data[data['Tiempo de anticipacion para renta del salon'] > 1]  # 2 y 3 son más de 3 meses

#Calcular la proporción de eventos que contrataron servicio extra para ambos grupos
proporcion_menos_3_meses = menos_3_meses['Servicio Extra'].value_counts(normalize=True).get('Si', 0)
proporcion_mas_3_meses = mas_3_meses['Servicio Extra'].value_counts(normalize=True).get('Si', 0)

#Comparación de proporciones
proporcion_comparacion = pd.DataFrame({
    'Grupo': ['Menos de 3 meses', 'Más de 3 meses'],
    'Proporción que contrató servicio extra': [proporcion_menos_3_meses, proporcion_mas_3_meses]
})

#Visualización en un gráfico de barras
plt.figure(figsize=(8, 5))
sns.barplot(x='Grupo', y='Proporción que contrató servicio extra', data=proporcion_comparacion, palette='viridis')
plt.title('Proporción de Contratación de Servicios Extra')
plt.ylabel('Proporción de Contratación de Servicio Extra')
plt.xlabel('Tiempo de Anticipación para la Renta del Salón')
plt.tight_layout()
plt.show()

#Imprimir los resultados de la comparación
print("\nComparación de Proporción de Contratación de Servicios Extra:\n")
print(proporcion_comparacion)
