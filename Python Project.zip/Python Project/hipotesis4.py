import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Cargar datos
data = pd.read_csv('eventos_limpios.csv', parse_dates=['Fecha del evento'])

#Filtrar eventos sociales: XV años y bodas
eventos_sociales = data[data['Tipo de evento'].str.lower().isin(['xv', 'boda'])].copy()

#Crear columna de mes
eventos_sociales['Mes'] = eventos_sociales['Fecha del evento'].dt.month

#Contar eventos por mes
conteo_mensual = eventos_sociales['Mes'].value_counts().sort_index()

#Mostrar conteo de todos los meses
print("Eventos sociales por mes:\n")
print(conteo_mensual)

#Mostrar solo los meses de final de año si existen
meses_final_ano = [10, 11, 12]
conteo_final_ano = conteo_mensual[conteo_mensual.index.isin(meses_final_ano)]

print("\nEventos sociales en octubre, noviembre y diciembre:\n")
print(conteo_final_ano if not conteo_final_ano.empty else "No hay eventos registrados en esos meses.")

#Gráfico
plt.figure(figsize=(10, 6))
sns.barplot(x=conteo_mensual.index, y=conteo_mensual.values, palette='pastel')
plt.title('Cantidad de eventos sociales (XV y bodas) por mes')
plt.xlabel('Mes del año')
plt.ylabel('Cantidad de eventos')
plt.xticks(range(0, 12), ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'])
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
